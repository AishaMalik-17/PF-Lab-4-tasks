#include<iostream>
using namespace std;
int main(){
	int a,z;
	int sum=0;
	cout<<"Enter any positive number: "<<endl;
	cin>>a;
	
	z=1;
	while(z<=a){
		sum+=z;
		z=z+2;
		
	}
	
	cout<<"Sum of all the odds numbers from 1 to "<<a<<" is = "<<sum<<endl;
	return 0;
}
