#include<iostream>
using namespace std;
int main(){
	int i,n;
	cout<<"Enter any positive number: ";
	cin>>n;
	
	for(i=n;i>=1;i--){
		cout<<i<<endl;
	}
	
	if(i=1){
		cout<<"!!!Stop!!!";

	}
	return 0;
}
